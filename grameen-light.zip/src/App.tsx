/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sun, 
  Moon, 
  MapPin, 
  AlertTriangle, 
  CheckCircle, 
  Zap, 
  Info,
  Clock,
  TrendingDown,
  LayoutDashboard,
  Map as MapIcon,
  ShieldCheck,
  Menu,
  X,
  History,
  Sparkles,
  Paperclip,
  FileText,
  Upload,
  BookOpen,
  Calendar,
  User as UserIcon,
  MessageSquare,
  TrendingUp,
  Activity,
  Award,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Pole, PoleStatus, Complaint, ComplaintStatus } from './types';
import { GoogleGenAI } from "@google/genai";
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';

// Firebase Imports
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDocs, 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  getDocFromServer,
  Timestamp,
  serverTimestamp,
  updateDoc,
  arrayUnion,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  onAuthStateChanged,
  GoogleAuthProvider
} from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with modern persistent cache settings
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
}, firebaseConfig.firestoreDatabaseId);

// auth initialization is moved after db to ensure clean flow
export const auth = getAuth();

// Firestore Error Handler
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test Connection function (will be called in useEffect)
async function performConnectionTest() {
  try {
    // We use getDocFromServer to force a network check
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("🔥 Firestore connection verified.");
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("⚠️ Firestore is in offline mode. This is normal if the network is restricted or during initial boot. Data will sync when back online.");
    } else {
      console.error("❌ Connection test failed:", error);
    }
  }
}

// Leaflet marker fix
const DefaultIcon = L.icon({
    iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// Constants for simulation
const TOTAL_POLES = 60;
const BULB_WATTAGE = 60; // watts
const VILLAGE_CENTER: [number, number] = [12.9716, 77.5946]; // Bangalore center for simulation

function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

function LegendItem({ color, label }: { color: string, label: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-3 h-3 rounded-full ${color}`} />
      <span className="text-[10px] font-bold opacity-80">{label}</span>
    </div>
  );
}

function DairyEntryForm({ 
  onSave, 
  night,
  onFileUpload
}: { 
  onSave: (data: { author: string, date: string, note: string }) => void,
  night: boolean,
  onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void
}) {
  const [author, setAuthor] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  return (
    <div className={`p-4 rounded-xl border mt-4 ${night ? 'bg-slate-800/30 border-slate-700' : 'bg-slate-100 border-slate-200'}`}>
      <div className="flex items-center gap-2 mb-3 text-blue-500">
        <BookOpen size={16} />
        <h4 className="text-xs font-bold uppercase tracking-wider">New Dairy Entry</h4>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-3">
        <div className="space-y-1">
          <label className="text-[10px] uppercase opacity-40 font-bold ml-1">Author / Official</label>
          <div className="relative">
            <UserIcon size={12} className="absolute left-3 top-2.5 opacity-30" />
            <input 
              type="text" 
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="Full Name"
              className={`w-full pl-8 pr-3 py-2 text-xs rounded-lg border outline-none focus:ring-1 focus:ring-blue-500 ${
                night ? 'bg-slate-900/50 border-slate-700' : 'bg-white border-slate-300'
              }`}
            />
          </div>
        </div>
        <div className="space-y-1">
          <label className="text-[10px] uppercase opacity-40 font-bold ml-1">Entry Date</label>
          <div className="relative">
            <Calendar size={12} className="absolute left-3 top-2.5 opacity-30" />
            <input 
              type="date" 
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className={`w-full pl-8 pr-3 py-2 text-xs rounded-lg border outline-none focus:ring-1 focus:ring-blue-500 ${
                night ? 'bg-slate-900/50 border-slate-700' : 'bg-white border-slate-300'
              }`}
            />
          </div>
        </div>
      </div>
      <div className="space-y-1 mb-3">
        <label className="text-[10px] uppercase opacity-40 font-bold ml-1">Service Log Note</label>
        <div className="relative">
          <MessageSquare size={12} className="absolute left-3 top-2.5 opacity-30" />
          <textarea 
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Describe action taken or observation..."
            rows={2}
            className={`w-full pl-8 pr-3 py-2 text-xs rounded-lg border outline-none focus:ring-1 focus:ring-blue-500 ${
              night ? 'bg-slate-900/50 border-slate-700' : 'bg-white border-slate-300'
            }`}
          />
        </div>
      </div>
      
      <div className="flex gap-2 mb-4">
        <label className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg border text-[10px] font-bold cursor-pointer transition-all ${
          night ? 'bg-slate-800 border-slate-700 hover:bg-slate-700' : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-600'
        }`}>
          <Paperclip size={14} />
          Attach Evidence
          <input type="file" className="hidden" onChange={onFileUpload} />
        </label>
      </div>

      <button 
        onClick={() => {
          if (!author || !note) {
            alert('Please fill in Author and Note fields.');
            return;
          }
          onSave({ author, date, note });
          setAuthor('');
          setNote('');
        }}
        className="w-full py-2 rounded-lg bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 active:scale-95 transition-all shadow-md"
      >
        File Official Entry
      </button>
    </div>
  );
}

import { localDb } from './db';
import { useLiveQuery } from 'dexie-react-hooks';

// ... existing code ...

export default function App() {
  const [isNightMode, setIsNightMode] = useState(true);
  const [poles, setPoles] = useState<Pole[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [selectedPole, setSelectedPole] = useState<Pole | null>(null);
  const [activeTab, setActiveTab] = useState<'map' | 'tracker' | 'dashboard' | 'leaderboard'>('map');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [expandedComplaintId, setExpandedComplaintId] = useState<string | null>(null);
  const [panchayatNoteInput, setPanchayatNoteInput] = useState<string>('');
  const [aiSummary, setAiSummary] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState<string[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isListening, setIsListening] = useState(false);
  const [userPoints, setUserPoints] = useState(parseInt(localStorage.getItem('user_points') || '0'));

  const [isAuthReady, setIsAuthReady] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'assistant', text: string }[]>([
    { role: 'assistant', text: "Namaste! I'm your Grameen-Light Assistant. How can I help you improve village energy efficiency today?" }
  ]);
  const [chatInput, setChatInput] = useState('');

  // Auth Initialization
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser(user);
        setIsAuthReady(true);
      } else {
        setUser(null);
        setIsAuthReady(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Login failed:", err);
      alert("Please enable Google Login in Firebase Console or try again.");
    }
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  // Local DB Queries using Dexie
  const localPoles = useLiveQuery(() => localDb.poles.toArray());
  const localComplaints = useLiveQuery(() => localDb.complaints.orderBy('timestamp').reverse().toArray());
  const pendingActions = useLiveQuery(() => localDb.offlineActions.toArray());

  // Connection Handler
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Run connection test with delay to allow initial setup
    const timer = setTimeout(() => {
      performConnectionTest();
    }, 3000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearTimeout(timer);
    };
  }, []);

  // Sync when online AND authenticated
  useEffect(() => {
    if (isOnline && isAuthReady && user) {
      syncOfflineActions();
    }
  }, [isOnline, isAuthReady, user]);

  const syncOfflineActions = async () => {
    if (!auth.currentUser) {
      console.log('Skipping offline sync: User not authenticated');
      return;
    }
    const actions = await localDb.offlineActions.toArray();
    if (actions.length === 0) return;
    
    console.log(`Syncing ${actions.length} offline actions...`);
    for (const action of actions) {
      try {
        if (action.type === 'REPORT') {
          await setDoc(doc(db, 'complaints', action.data.id), action.data);
          await updateDoc(doc(db, 'poles', action.data.poleId), { status: action.data.issueType });
        } else if (action.type === 'UPDATE_STATUS') {
          const { complaintId, ...updateData } = action.data;
          // Note: updateData might contain history/notes which are complex
          await updateDoc(doc(db, 'complaints', complaintId), updateData);
        }
        await localDb.offlineActions.delete(action.id!);
      } catch (e) {
        console.error('Sync failed for action:', action.id, e);
        // If it's a permission error, we might want to stop syncing and wait for login/reauth
      }
    }
  };

  // Firestore Sync: Poles
  useEffect(() => {
    if (!isOnline) {
      if (localPoles) setPoles(localPoles);
      return;
    }

    const q = query(collection(db, 'poles'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const polesData = snapshot.docs.map(doc => doc.data() as Pole);
      
      if (polesData.length === 0) {
        // Initialize once if empty
        const initialPoles: Pole[] = Array.from({ length: TOTAL_POLES }).map((_, i) => ({
          id: `P-${(i + 1).toString().padStart(3, '0')}`,
          status: Math.random() > 0.8 ? (Math.random() > 0.5 ? 'Fused' : 'Daytime_On') : 'Working',
          location: `Sector ${Math.floor(i / 6) + 1}, Lane ${(i % 6) + 1}`,
          lat: VILLAGE_CENTER[0] + (Math.random() - 0.5) * 0.015,
          lng: VILLAGE_CENTER[1] + (Math.random() - 0.5) * 0.015
        }));
        
        // Use user state from component instead of auth.currentUser directly to react to login
        if (user) {
          initialPoles.forEach(async (p) => {
            try {
              await setDoc(doc(db, 'poles', p.id), p);
              await localDb.poles.put(p);
            } catch (e) {
              handleFirestoreError(e, OperationType.WRITE, `poles/${p.id}`);
            }
          });
        } else {
          console.log("Database is empty. Please sign in to initialize village data.");
          setPoles(initialPoles); // Show locally even if not saved to server
        }
      } else {
        setPoles(polesData);
        polesData.forEach(p => localDb.poles.put(p));
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, 'poles'));

    return () => unsubscribe();
  }, [isOnline, user]); // Added user as dependency

  // Firestore Sync: Complaints
  useEffect(() => {
    if (!isOnline) {
      if (localComplaints) setComplaints(localComplaints);
      return;
    }

    const q = query(collection(db, 'complaints'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const complaintsData = snapshot.docs.map(doc => doc.data() as Complaint);
      setComplaints(complaintsData);
      complaintsData.forEach(c => localDb.complaints.put(c));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'complaints'));

    return () => unsubscribe();
  }, [isOnline]);

  // Voice Command Setup
  const startVoiceCommand = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice recognition not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      console.log('Voice Command:', transcript);
      
      // Smart matching
      const poleMatch = transcript.match(/pole\s*(p-?\d+)/);
      const statusMatch = transcript.match(/fused|working|wasting|on|dark/);
      
      if (poleMatch) {
        const id = poleMatch[1].replace('-', '').padStart(3, '0');
        const fullId = `P-${id}`;
        const pole = poles.find(p => p.id === fullId);
        if (pole) {
          setSelectedPole(pole);
          alert(`Selected Pole ${fullId}. What is the issue?`);
        } else {
          alert(`Pole ${fullId} not found.`);
        }
      } else if (chatInput === '') {
        setChatInput(transcript);
        // Also trigger AI chat if open
        if (isAiChatOpen) handleChatSubmit({ preventDefault: () => {} } as any);
      }
    };

    recognition.start();
  };

  const addPoints = (amount: number) => {
    const newPoints = userPoints + amount;
    setUserPoints(newPoints);
    localStorage.setItem('user_points', newPoints.toString());
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg = chatInput;
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `
        Context: The user is using Grameen-Light, a village streetlight audit app.
        Village Status: ${stats.daytimeOnCount} poles wasting energy, ${stats.fusedCount} fused bulbs.
        Saved: ${stats.historicalSavings.toFixed(1)} kWh.
        
        Answer the following question as a helpful village assistant: ${userMsg}
      `;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      
      setChatMessages(prev => [...prev, { role: 'assistant', text: response.text || 'I am processing your request.' }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { role: 'assistant', text: 'Sorry, I encountered an error. Please try again.' }]);
    }
  };

  // Calculations
  const stats = useMemo(() => {
    const fusedCount = poles.filter(p => p.status === 'Fused').length;
    const daytimeOnCount = poles.filter(p => p.status === 'Daytime_On').length;
    // Energy waste logic: if burning in day, we save energy by reporting it
    // Simulating energy saved based on current "Daytime_On" being reported/fixed
    // For this dashboard, we'll show "Potential Savings" and "Historical Savings"
    const historicalSavings = complaints
      .filter(c => c.status === 'Fixed' && c.issueType === 'Daytime_On')
      .length * 12 * BULB_WATTAGE / 1000; // Assuming 12h of day usage per day

    return {
      fusedCount,
      daytimeOnCount,
      historicalSavings
    };
  }, [poles, complaints]);

  const generateComplaintId = (poleId: string) => {
    const ts = Date.now().toString().slice(-4);
    return `GRM-${poleId}-${ts}`;
  };

  const handleReport = async (issue: PoleStatus) => {
    if (!selectedPole) return;
    
    if (isOnline && !auth.currentUser) {
      alert("Please Sign In to submit a report.");
      handleLogin();
      return;
    }

    const cid = generateComplaintId(selectedPole.id);
    const newComplaint: Complaint = {
      id: cid,
      poleId: selectedPole.id,
      issueType: issue,
      status: 'Pending',
      timestamp: Date.now(),
      history: [
        { status: 'Pending', timestamp: Date.now(), note: 'Resident reported issue.' }
      ]
    };

    try {
      if (isOnline) {
        // Save Complaint to Firestore
        await setDoc(doc(db, 'complaints', cid), newComplaint);
        // Update Pole Status in Firestore
        await updateDoc(doc(db, 'poles', selectedPole.id), { status: issue });
      } else {
        // Save to Local DB + Offline Actions
        await localDb.complaints.put(newComplaint);
        await localDb.offlineActions.add({
          type: 'REPORT',
          data: newComplaint,
          timestamp: Date.now()
        });
        await localDb.poles.update(selectedPole.id, { status: issue });
        setComplaints([newComplaint, ...complaints]);
      }

      addPoints(10); // Reward citizen
      setSelectedPole(null);
      setPendingAttachments([]);
      alert(isOnline ? `Report Submitted! ID: ${cid}` : `Offline Report Saved. Will sync later. ID: ${cid}`);
    } catch (e) {
      if (isOnline) handleFirestoreError(e, OperationType.WRITE, `complaints/${cid}`);
    }
  };

  const handleAiAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `
        As an Energy Consultant for Grameen-Light, analyze the following village metrics:
        - Total Poles: ${TOTAL_POLES}
        - Wasting (Daytime On): ${stats.daytimeOnCount}
        - Fused (Night Dark): ${stats.fusedCount}
        - Historical Energy Saved: ${stats.historicalSavings.toFixed(2)} kWh
        
        Provide a concise 3-sentence summary of the village status and 2 actionable recommendations for the Panchayat.
        Formatting: Plain text, bullet points for recommendations.
      `;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      
      setAiSummary(response.text || 'Analysis currently unavailable.');
    } catch (error) {
      console.error('AI Error:', error);
      setAiSummary('Failed to generate AI insights. Please check connection.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const simulateFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isForAction: boolean = false, complaintId?: string) => {
    const files = e.target.files;
    if (files && files[0]) {
      // Simulate file upload with placeholder label
      const fileName = files[0].name;
      if (isForAction && complaintId) {
        updateComplaintStatus(complaintId, complaints.find(c => c.id === complaintId)?.status || 'Pending', `Attached document: ${fileName}`, [fileName]);
      } else {
        setPendingAttachments(prev => [...prev, fileName]);
      }
    }
  };

  const updateComplaintStatus = async (complaintId: string, newStatus: ComplaintStatus, note?: string, attachments?: string[]) => {
    try {
      const historyEvent = { status: newStatus, timestamp: Date.now(), note, attachments };
      
      if (isOnline) {
        const compRef = doc(db, 'complaints', complaintId);
        await updateDoc(compRef, {
          status: newStatus,
          panchayatNotes: note || '',
          history: arrayUnion(historyEvent),
          attachments: attachments ? arrayUnion(...attachments) : arrayUnion()
        });
      } else {
        await localDb.offlineActions.add({
          type: 'UPDATE_STATUS',
          data: { complaintId, status: newStatus, panchayatNotes: note || '', history: historyEvent, attachments },
          timestamp: Date.now()
        });
        // Optimistic local update
        setComplaints(prev => prev.map(c => c.id === complaintId ? { ...c, status: newStatus, history: [...c.history, historyEvent] } : c));
      }

      if (newStatus === 'Fixed') {
        addPoints(50); // Reward fixer
        const complaint = complaints.find(c => c.id === complaintId);
        if (complaint) {
          if (isOnline) await updateDoc(doc(db, 'poles', complaint.poleId), { status: 'Working' });
          else await localDb.poles.update(complaint.poleId, { status: 'Working' });
        }
      }
    } catch (e) {
      if (isOnline) handleFirestoreError(e, OperationType.UPDATE, `complaints/${complaintId}`);
    }
  };

  const getStatusColor = (status: PoleStatus) => {
    if (isNightMode) {
      switch (status) {
        case 'Working': return 'bg-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.6)]';
        case 'Fused': return 'bg-gray-600';
        case 'Daytime_On': return 'bg-yellow-100 opacity-80';
        default: return 'bg-gray-400';
      }
    } else {
      switch (status) {
        case 'Working': return 'bg-gray-200';
        case 'Fused': return 'bg-red-400';
        case 'Daytime_On': return 'bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.5)]';
        default: return 'bg-gray-300';
      }
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-700 ${isNightMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[50] lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={`fixed left-0 top-0 bottom-0 w-72 z-[51] p-6 lg:hidden border-r shadow-2xl ${
                isNightMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <Zap className="text-yellow-500" size={24} fill="currentColor" />
                  <span className="font-bold text-lg">Menu</span>
                </div>
                <button onClick={() => setIsSidebarOpen(false)} className="p-2 opacity-60">
                  <X size={24} />
                </button>
              </div>

              <nav className="flex flex-col gap-2">
                <NavButton 
                  active={activeTab === 'map'} 
                  onClick={() => { setActiveTab('map'); setIsSidebarOpen(false); }} 
                  icon={<MapIcon size={20} />} 
                  label="Pole Map" 
                  night={isNightMode} 
                />
                <NavButton 
                  active={activeTab === 'tracker'} 
                  onClick={() => { setActiveTab('tracker'); setIsSidebarOpen(false); }} 
                  icon={<History size={20} />} 
                  label="Repair Tracker" 
                  night={isNightMode} 
                  count={complaints.filter(c => c.status !== 'Fixed').length}
                />
                <NavButton 
                  active={activeTab === 'dashboard'} 
                  onClick={() => { setActiveTab('dashboard'); setIsSidebarOpen(false); }} 
                  icon={<LayoutDashboard size={20} />} 
                  label="Impact Stats" 
                  night={isNightMode} 
                />
                <NavButton 
                  active={activeTab === 'leaderboard'} 
                  onClick={() => { setActiveTab('leaderboard'); setIsSidebarOpen(false); }} 
                  icon={<ShieldCheck size={20} />} 
                  label="Leaderboard" 
                  night={isNightMode} 
                />
              </nav>

              <div className="absolute bottom-10 left-6 right-6">
                <div className={`p-4 rounded-xl border ${isNightMode ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                  <p className="text-[10px] font-bold uppercase opacity-40 mb-2">System Status</p>
                  <div className="text-xs font-medium text-green-500 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    Cloud Sync Active
                  </div>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Background Ambience */}
      <div className={`fixed inset-0 pointer-events-none opacity-20 transition-opacity duration-1000 ${isNightMode ? 'bg-[radial-gradient(circle_at_50%_0%,#1e293b,transparent)]' : 'bg-[radial-gradient(circle_at_50%_0%,#cbd5e1,transparent)]'}`} />

      {/* Live Activity Ticker */}
      <div className={`hidden sm:block py-2 text-[10px] uppercase tracking-widest font-bold transition-colors border-b ${
        isNightMode ? 'bg-slate-900/40 border-slate-800 text-indigo-400' : 'bg-indigo-50 border-indigo-100 text-indigo-600'
      }`}>
        <div className="max-w-5xl mx-auto px-6 overflow-hidden flex items-center gap-8">
          <div className="flex items-center gap-2 shrink-0">
            <Activity size={12} className="animate-pulse" />
            Village Live:
          </div>
          <div className="flex-1 whitespace-nowrap overflow-hidden relative">
            <motion.div 
              animate={{ x: [0, -1000] }}
              transition={{ repeat: Infinity, duration: 30, ease: "linear" }}
              className="flex gap-24 pr-24"
            >
              <span className="flex items-center gap-2 shrink-0"><Award size={10} /> {userPoints} points accumulated by your account</span>
              <span className="flex items-center gap-2 shrink-0"><TrendingUp size={10} /> {stats.historicalSavings.toFixed(1)} kWh energy saved village-wide</span>
              <span className="flex items-center gap-2 shrink-0"><MapPin size={10} /> {complaints.filter(c => c.status === 'Fixed').length} fused bulbs restored recently</span>
              <span className="flex items-center gap-2 shrink-0"><Zap size={10} /> {stats.daytimeOnCount} daytime energy leaks identified</span>
              {/* Duplicate for seamless loop */}
              <span className="flex items-center gap-2 shrink-0"><Award size={10} /> {userPoints} points accumulated by your account</span>
              <span className="flex items-center gap-2 shrink-0"><TrendingUp size={10} /> {stats.historicalSavings.toFixed(1)} kWh energy saved village-wide</span>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors ${isNightMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'}`}>
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg lg:hidden"
            >
              <Menu size={24} />
            </button>
            <div className="bg-yellow-500 p-2 rounded-xl">
              <Zap className="text-slate-900" size={20} fill="currentColor" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Grameen-Light</h1>
              <p className="text-[10px] uppercase tracking-widest font-semibold opacity-60">Citizen audit • Village 042</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold border transition-colors ${
              isOnline ? (isNightMode ? 'bg-green-500/10 border-green-500/30 text-green-400' : 'bg-green-50 border-green-200 text-green-600') : 'bg-red-500/10 border-red-500/30 text-red-400'
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
              {isOnline ? 'Real-time Sync' : 'Offline Mode'}
              {pendingActions && pendingActions.length > 0 && (
                <span className="ml-1 bg-yellow-500 text-slate-900 px-1.5 py-0.5 rounded-md animate-bounce">
                  {pendingActions.length} pending
                </span>
              )}
            </div>
            
            {isOnline && !user ? (
              <button
                onClick={handleLogin}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-md active:scale-95"
              >
                <UserIcon size={14} />
                Sign In
              </button>
            ) : isOnline && user ? (
              <div className="flex items-center gap-2">
                <div className={`hidden md:block text-right mr-1`}>
                  <p className="text-[10px] font-black uppercase opacity-60">Citizen Profile</p>
                  <p className="text-xs font-bold truncate max-w-[100px]">{user.displayName || 'Guardian'}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className={`p-2 rounded-full border transition-colors ${
                    isNightMode ? 'bg-slate-800 border-slate-700 hover:text-red-400' : 'bg-white border-slate-200 hover:text-red-500 shadow-sm'
                  }`}
                  title="Sign Out"
                >
                  <LogOut size={16} />
                </button>
              </div>
            ) : null}

            <button
              onClick={() => setIsNightMode(!isNightMode)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                isNightMode 
                ? 'bg-slate-800 text-yellow-400 ring-1 ring-slate-700' 
                : 'bg-white text-slate-600 ring-1 ring-slate-200 shadow-sm'
              }`}
            >
              {isNightMode ? <Moon size={14} fill="currentColor" /> : <Sun size={14} fill="currentColor" />}
              {isNightMode ? 'Night view' : 'Day view'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto p-4 flex gap-6">
        
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden lg:flex flex-col gap-2 w-56 sticky top-20 h-fit">
          <NavButton 
            active={activeTab === 'map'} 
            onClick={() => setActiveTab('map')} 
            icon={<MapIcon size={20} />} 
            label="Pole Map" 
            night={isNightMode} 
          />
          <NavButton 
            active={activeTab === 'tracker'} 
            onClick={() => setActiveTab('tracker')} 
            icon={<History size={20} />} 
            label="Repair Tracker" 
            night={isNightMode} 
            count={complaints.filter(c => c.status !== 'Fixed').length}
          />
          <NavButton 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
            icon={<LayoutDashboard size={20} />} 
            label="Impact Stats" 
            night={isNightMode} 
          />
          <NavButton 
            active={activeTab === 'leaderboard'} 
            onClick={() => setActiveTab('leaderboard')} 
            icon={<ShieldCheck size={20} />} 
            label="Guardians" 
            night={isNightMode} 
          />
        </aside>

        <section className="flex-1">
          <AnimatePresence mode="wait">
            {activeTab === 'map' && (
              <motion.div
                key="map"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="h-[600px] rounded-3xl overflow-hidden border shadow-2xl relative"
                style={{ zIndex: 0 }}
              >
                <MapContainer 
                  center={VILLAGE_CENTER} 
                  zoom={15} 
                  className="h-full w-full"
                  scrollWheelZoom={true}
                >
                  <TileLayer
                    url={isNightMode 
                      ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                      : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    }
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  />
                  {poles.map((pole) => (
                    <Marker 
                      key={pole.id} 
                      position={[pole.lat, pole.lng]}
                      icon={L.divIcon({
                        className: 'custom-div-icon',
                        html: `<div class="p-1 px-2 rounded-full border-2 border-white shadow-lg text-[8px] font-bold ${
                          pole.status === 'Working' ? 'bg-yellow-400 text-slate-900 border-yellow-200' : 
                          pole.status === 'Fused' ? 'bg-slate-700 text-slate-100 border-slate-500' : 
                          'bg-red-500 text-white border-red-200'
                        }">${pole.id}</div>`,
                        iconSize: [24, 24],
                        iconAnchor: [12, 12]
                      })}
                      eventHandlers={{
                        click: () => setSelectedPole(pole),
                      }}
                    >
                      <Popup>
                        <div className="p-1">
                          <p className="font-bold text-xs">Pole {pole.id}</p>
                          <p className="text-[10px] opacity-60">{pole.location}</p>
                          <p className="text-[10px] font-bold mt-1">Status: {pole.status}</p>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                  <MapUpdater center={VILLAGE_CENTER} />
                </MapContainer>

                {/* Overlaid Legend */}
                <div className={`absolute bottom-6 right-6 p-3 rounded-2xl border backdrop-blur-md z-[1000] ${
                  isNightMode ? 'bg-slate-900/90 border-slate-700 text-slate-200' : 'bg-white/90 border-slate-200 text-slate-800'
                }`}>
                  <h4 className="text-[10px] font-bold uppercase tracking-widest mb-2">Pole Status</h4>
                  <div className="space-y-1.5">
                    <LegendItem color="bg-yellow-400" label="Working" />
                    <LegendItem color="bg-slate-600" label="Fused" />
                    <LegendItem color="bg-red-500" label="Daytime On" />
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'tracker' && (
              <motion.div
                key="tracker"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">Repair Tracker</h2>
                  <div className={`px-3 py-1 rounded-lg text-xs font-bold border ${isNightMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
                    {complaints.length} Total Reports
                  </div>
                </div>

                {complaints.length === 0 ? (
                  <div className={`p-12 text-center rounded-2xl border-2 border-dashed ${isNightMode ? 'border-slate-800 text-slate-500' : 'border-slate-200 text-slate-400'}`}>
                    <CheckCircle className="mx-auto mb-4 opacity-50" size={48} />
                    <p className="font-medium">No complaints active.</p>
                    <p className="text-sm">Great job keeping the village lights healthy!</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {complaints.map((complaint) => (
                      <div 
                        key={complaint.id}
                        className={`overflow-hidden rounded-2xl border transition-all ${
                          isNightMode ? 'bg-slate-900/50 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                        }`}
                      >
                        <div 
                          className="p-4 cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors"
                          onClick={() => setExpandedComplaintId(expandedComplaintId === complaint.id ? null : complaint.id)}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex gap-4">
                              <div className={`p-3 rounded-xl ${
                                complaint.issueType === 'Fused' ? 'bg-red-500/10 text-red-500' : 'bg-yellow-500/10 text-yellow-500'
                              }`}>
                                {complaint.issueType === 'Fused' ? <AlertTriangle size={20} /> : <Zap size={20} />}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-bold text-sm">{complaint.id}</h3>
                                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 opacity-60">Pole {complaint.poleId}</span>
                                </div>
                                <p className="text-xs opacity-60 mt-0.5">
                                  Issue: {complaint.issueType === 'Fused' ? 'Bulb Fused' : 'Burning in Day'}
                                </p>
                                <div className="flex items-center gap-2 mt-2 text-[10px] opacity-40">
                                  <Clock size={10} />
                                  {new Date(complaint.timestamp).toLocaleString()}
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex flex-col items-end gap-2">
                              <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                                complaint.status === 'Pending' ? 'bg-orange-500/20 text-orange-500' :
                                complaint.status === 'Assigned' ? 'bg-blue-500/20 text-blue-500' :
                                'bg-green-500/20 text-green-500'
                              }`}>
                                {complaint.status}
                              </span>
                              <div className="text-[10px] font-bold text-blue-500 opacity-60">
                                {expandedComplaintId === complaint.id ? 'Hide Details' : 'View History'}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* History Detail Section */}
                        <AnimatePresence>
                          {expandedComplaintId === complaint.id && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className={`border-t ${isNightMode ? 'border-slate-800 bg-slate-900/30' : 'border-slate-100 bg-slate-50/30'}`}
                            >
                              <div className="p-4 space-y-4">
                                <div>
                                  <h4 className="text-[10px] font-bold uppercase tracking-widest opacity-40 mb-3">Repair Timeline</h4>
                                  <div className="space-y-4 relative before:absolute before:left-[7px] before:top-2 before:bottom-2 before:w-[1px] before:bg-slate-700 dark:before:bg-slate-800">
                                    {(complaint.history || []).map((event, idx) => (
                                      <div key={idx} className="relative pl-6 flex flex-col gap-1">
                                        <div className={`absolute left-0 top-1.5 w-3.5 h-3.5 rounded-full border-2 ${
                                          isNightMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
                                        } transition-colors ${
                                          idx === 0 ? 'border-blue-500' : ''
                                        }`} />
                                        <div className="flex items-center justify-between">
                                          <span className="text-xs font-bold leading-none">{event.status}</span>
                                          <span className="text-[10px] opacity-40 leading-none">{new Date(event.timestamp).toLocaleString()}</span>
                                        </div>
                                        {event.note && (
                                          <p className="text-[11px] opacity-70 italic">"{event.note}"</p>
                                        )}
                                        {event.attachments && event.attachments.length > 0 && (
                                          <div className="flex flex-wrap gap-2 mt-1">
                                            {event.attachments.map((file, fIdx) => (
                                              <div key={fIdx} className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[9px] border dark:border-slate-700">
                                                <FileText size={10} />
                                                {file}
                                              </div>
                                            ))}
                                          </div>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                {complaint.status !== 'Fixed' && (
                                  <div className="pt-4 border-t border-slate-800/20 dark:border-slate-200/5">
                                    <h4 className="text-[10px] font-bold uppercase tracking-widest opacity-40 mb-2">Panchayat Action Registry</h4>
                                    
                                    <DairyEntryForm 
                                      night={isNightMode}
                                      onFileUpload={(e) => simulateFileUpload(e, true, complaint.id)}
                                      onSave={(data) => {
                                        updateComplaintStatus(complaint.id, complaint.status, `[Official: ${data.author}] ${data.note}`);
                                      }}
                                    />

                                    <div className="flex flex-wrap gap-2 mt-4">
                                      {complaint.status === 'Pending' && (
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            updateComplaintStatus(complaint.id, 'Assigned', 'Status updated to Assigned by Panchayat Registry.');
                                          }}
                                          className={`flex-1 min-w-[100px] py-2 px-3 rounded-lg text-[10px] font-bold transition-all ${
                                            isNightMode ? 'bg-blue-500/20 text-blue-400 hover:bg-blue-500/30' : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
                                          }`}
                                        >
                                          Official Assignment
                                        </button>
                                      )}
                                      
                                      {(complaint.status === 'Pending' || complaint.status === 'Assigned') && (
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            updateComplaintStatus(complaint.id, 'Fixed', 'Official Certification of Repair.');
                                          }}
                                          className={`flex-1 min-w-[100px] py-2 px-3 rounded-lg text-[10px] font-bold transition-all ${
                                            isNightMode ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30' : 'bg-green-50 text-green-600 hover:bg-green-100'
                                          }`}
                                        >
                                          Certify Repair
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                {/* AI Insights Card */}
                <div className={`p-6 rounded-2xl border overflow-hidden relative ${isNightMode ? 'bg-indigo-900/20 border-indigo-500/30' : 'bg-indigo-50 border-indigo-200'}`}>
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <Sparkles size={120} />
                  </div>
                  
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Sparkles className="text-indigo-500" size={20} />
                        <h3 className="font-bold">Village Intelligence (AI)</h3>
                      </div>
                      <button 
                        onClick={handleAiAnalyze}
                        disabled={isAnalyzing}
                        className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all shadow-sm ${
                          isAnalyzing 
                            ? 'opacity-50 cursor-not-allowed bg-slate-200 text-slate-500' 
                            : 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95'
                        }`}
                      >
                        {isAnalyzing ? 'Analyzing Village...' : 'Generate AI Report'}
                      </button>
                    </div>

                    <div className={`p-4 rounded-xl border min-h-[100px] whitespace-pre-line ${
                      isNightMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-indigo-100 shadow-sm'
                    }`}>
                      {aiSummary ? (
                        <div className="text-sm leading-relaxed opacity-90">
                          {aiSummary}
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full opacity-40 text-center py-4">
                          <LayoutDashboard size={32} className="mb-2" />
                          <p className="text-xs font-medium italic">Click "Generate" to see smart optimization goals for Sector 4.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <StatCard 
                    icon={<Zap size={24} className="text-yellow-500" />}
                    label="Wasted Energy Reported"
                    value={`${stats.historicalSavings.toFixed(1)} kWh`}
                    sub="Saved this month"
                    night={isNightMode}
                  />
                  <StatCard 
                    icon={<ShieldCheck size={24} className="text-green-500" />}
                    label="Public Safety Coverage"
                    value={`${(( (TOTAL_POLES - stats.fusedCount) / TOTAL_POLES) * 100).toFixed(0)}%`}
                    sub="Active Night Lighting"
                    night={isNightMode}
                  />
                </div>

                <div className={`p-6 rounded-2xl border ${isNightMode ? 'bg-slate-900/50 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
                  <h3 className="font-bold mb-4 flex items-center gap-2">
                    <TrendingDown size={18} className="text-yellow-500" />
                    Wastage Insights
                  </h3>
                  <div className="h-4 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden mb-2">
                    <div 
                      className="h-full bg-yellow-500 transition-all duration-1000" 
                      style={{ width: `${(stats.daytimeOnCount / TOTAL_POLES) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-bold uppercase opacity-60">
                    <span>{stats.daytimeOnCount} Wasting Poles</span>
                    <span>{TOTAL_POLES} Total</span>
                  </div>
                  
                  <div className={`mt-6 p-5 rounded-2xl border-2 border-dashed transition-all ${isNightMode ? 'bg-indigo-500/5 border-indigo-500/20' : 'bg-indigo-50/50 border-indigo-200'}`}>
                    <div className="flex gap-4">
                      <div className="bg-indigo-500 p-2 rounded-xl h-fit">
                        <Sparkles className="text-white" size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold mb-1">Impact Insight</h4>
                        <div className="text-xs opacity-80 italic leading-relaxed">
                          "Smart villages start with community eyes. {stats.daytimeOnCount > 0 ? (
                            <span>By reporting the <span className="font-bold text-red-500">{stats.daytimeOnCount} 'Daytime On'</span> poles, you could save enough energy to light up <span className="font-bold text-yellow-500">{(stats.daytimeOnCount * 1.5).toFixed(0)} new dark lanes</span> for an entire month."</span>
                          ) : (
                            <span>The village is currently <span className="font-bold text-green-500">Energy Efficient</span>! Your reports have already helped save <span className="font-bold text-indigo-500">{stats.historicalSavings.toFixed(1)} kWh</span> so far."</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'leaderboard' && (
              <motion.div
                key="leaderboard"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h2 className="text-xl font-bold">Village Energy Guardians</h2>
                    <p className="text-sm opacity-60">Citizen audit leaderboard • Earn points by reporting</p>
                  </div>
                  <div className={`p-4 rounded-2xl border text-center ${isNightMode ? 'bg-indigo-600/20 border-indigo-500/30' : 'bg-indigo-50 border-indigo-100'}`}>
                    <p className="text-[10px] font-bold uppercase opacity-40">Your Points</p>
                    <p className="text-2xl font-black text-indigo-500">{userPoints}</p>
                  </div>
                </div>

                <div className={`rounded-3xl border overflow-hidden ${isNightMode ? 'bg-slate-900/50 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
                  {[
                    { name: "Priya Sharma", points: 1240, rank: 1, avatar: "PS" },
                    { name: "Rajesh Kumar", points: 980, rank: 2, avatar: "RK" },
                    { name: "Amit Patel", points: 850, rank: 3, avatar: "AP" },
                    { name: "Meena Devi", points: 720, rank: 4, avatar: "MD" },
                    { name: "You (Citizen Observer)", points: userPoints, rank: userPoints > 1000 ? 1 : (userPoints > 500 ? 3 : 5), avatar: "ME", highlighted: true }
                  ].sort((a,b) => b.points - a.points).map((user, idx) => (
                    <div key={idx} className={`flex items-center justify-between p-4 border-b last:border-0 ${user.highlighted ? (isNightMode ? 'bg-indigo-500/10' : 'bg-indigo-50') : ''}`}>
                      <div className="flex items-center gap-4">
                        <div className="text-xs font-bold opacity-40 w-4">{idx + 1}</div>
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs ${isNightMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                          {user.avatar}
                        </div>
                        <div>
                          <p className="font-bold text-sm">{user.name}</p>
                          <p className="text-[10px] opacity-40">{user.points > 1000 ? 'Village Hero' : 'Guardian'}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Zap size={14} className="text-yellow-500" fill="currentColor" />
                        <span className="font-black text-sm">{user.points}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      {/* Floating Report Modal */}
      <AnimatePresence>
        {selectedPole && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedPole(null)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            <motion.div
              layoutId={selectedPole.id}
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className={`relative w-full max-w-sm p-6 rounded-3xl border shadow-2xl transition-colors ${
                isNightMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
              }`}
            >
              <button 
                onClick={() => setSelectedPole(null)}
                className="absolute top-4 right-4 p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg opacity-60"
              >
                <X size={20} />
              </button>

              <div className="flex items-center gap-4 mb-6">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-yellow-500 text-slate-900`}>
                  <MapPin size={24} fill="currentColor" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">Pole {selectedPole.id}</h2>
                  <p className="text-xs opacity-60">{selectedPole.location}</p>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-sm font-semibold mb-2 opacity-80 tracking-wide uppercase text-[10px]">What's the status?</p>
                
                <div className="flex items-center gap-2 mb-2">
                  <button 
                    onClick={startVoiceCommand}
                    className={`w-full flex items-center justify-center gap-2 p-3 rounded-2xl border text-xs font-bold transition-all ${
                      isListening ? 'bg-red-500 text-white animate-pulse' : (isNightMode ? 'bg-slate-800 border-slate-700 hover:bg-slate-700' : 'bg-slate-50 border-slate-200 hover:bg-white')
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full ${isListening ? 'bg-white animate-ping' : 'bg-red-500'}`} />
                    {isListening ? 'Listening...' : 'Voice Report (Beta)'}
                  </button>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  <label className={`w-full cursor-pointer flex items-center justify-center gap-2 p-3 rounded-2xl border text-xs font-bold transition-all ${
                    isNightMode ? 'bg-slate-800 border-slate-700 hover:bg-slate-700' : 'bg-slate-50 border-slate-200 hover:bg-white'
                  }`}>
                    <Upload size={16} />
                    {pendingAttachments.length > 0 ? `${pendingAttachments.length} Files Selected` : 'Evidence Upload'}
                    <input type="file" className="hidden" multiple onChange={(e) => simulateFileUpload(e)} />
                  </label>
                  {pendingAttachments.length > 0 && (
                    <button onClick={() => setPendingAttachments([])} className="p-3 rounded-2xl text-red-500 bg-red-500/10 active:scale-95 transition-transform">
                      <X size={16} />
                    </button>
                  )}
                </div>

                <ReportAction 
                  icon={<Zap size={20} className="text-yellow-500" />}
                  label="Working Perfectly"
                  sub="No issues detected"
                  onClick={() => handleReport('Working')}
                  night={isNightMode}
                />
                
                <ReportAction 
                  icon={<AlertTriangle size={20} className="text-red-500" />}
                  label="Bulb Fused"
                  sub="The area is dark at night"
                  onClick={() => handleReport('Fused')}
                  night={isNightMode}
                />
                
                <ReportAction 
                  icon={<Zap size={20} className="text-orange-500" fill="currentColor" />}
                  label="Burning in Daytime"
                  sub="Energy is being wasted"
                  onClick={() => handleReport('Daytime_On')}
                  night={isNightMode}
                />
              </div>

              <p className="mt-6 text-[10px] text-center opacity-40">
                Your report creates an instant digital bridge to the Panchayat Office.
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating AI Assistant */}
      <div className="fixed bottom-24 lg:bottom-10 right-6 z-50 flex flex-col items-end gap-4">
        <AnimatePresence>
          {isAiChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className={`w-80 sm:w-96 rounded-3xl border shadow-2xl overflow-hidden mb-2 ${
                isNightMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'
              }`}
            >
              <div className="p-4 bg-indigo-600 text-white flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold">
                  <Sparkles size={20} />
                  Village AI Assistant
                </div>
                <button onClick={() => setIsAiChatOpen(false)} className="hover:bg-indigo-500 p-1 rounded">
                  <X size={20} />
                </button>
              </div>
              <div className="h-80 overflow-y-auto p-4 flex flex-col gap-4 bg-transparent">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-3 rounded-2xl text-xs ${
                      msg.role === 'user' 
                        ? 'bg-indigo-600 text-white rounded-tr-none' 
                        : isNightMode ? 'bg-slate-800 text-slate-200 rounded-tl-none' : 'bg-slate-100 text-slate-800 rounded-tl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>
              <form onSubmit={handleChatSubmit} className={`p-3 border-t flex gap-2 ${isNightMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                <input 
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask about village poles..."
                  className={`flex-1 px-3 py-2 rounded-xl text-xs outline-none border focus:ring-1 focus:ring-indigo-500 ${
                    isNightMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'
                  }`}
                />
                <button type="submit" className="bg-indigo-600 text-white p-2 rounded-xl hover:bg-indigo-700 shadow-md">
                  <BookOpen size={18} />
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsAiChatOpen(!isAiChatOpen)}
          className={`p-4 rounded-3xl shadow-2xl flex items-center justify-center transition-all ${
            isAiChatOpen 
              ? 'bg-indigo-600 text-white' 
              : 'bg-indigo-500 text-white'
          }`}
        >
          <Sparkles className={isAiChatOpen ? 'rotate-12' : ''} size={28} />
        </motion.button>
      </div>

      {/* Mobile Navigation Bar */}
      <div className={`lg:hidden fixed bottom-0 left-0 right-0 z-40 border-t backdrop-blur-md px-6 py-2 flex justify-between items-center transition-colors ${
        isNightMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white/90 border-slate-200'
      }`}>
        <MobileNavIcon active={activeTab === 'map'} icon={<MapIcon size={24} />} onClick={() => setActiveTab('map')} />
        <MobileNavIcon active={activeTab === 'tracker'} icon={<History size={24} />} onClick={() => setActiveTab('tracker')} />
        <MobileNavIcon active={activeTab === 'dashboard'} icon={<LayoutDashboard size={24} />} onClick={() => setActiveTab('dashboard')} />
      </div>
    </div>
  );
}

function NavButton({ active, onClick, icon, label, night, count }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string, night: boolean, count?: number }) {
  return (
    <button
      onClick={onClick}
      className={`relative w-full flex items-center justify-between px-4 py-3 rounded-xl font-semibold text-sm transition-all ${
        active 
          ? night 
            ? 'bg-slate-800 text-yellow-400 ring-1 ring-slate-700 shadow-xl' 
            : 'bg-white text-slate-900 ring-1 ring-slate-200 shadow-md'
          : 'text-slate-500 hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
      }`}
    >
      <div className="flex items-center gap-3">
        {icon}
        {label}
      </div>
      {count !== undefined && count > 0 && (
        <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full ring-2 ring-white dark:ring-slate-900">
          {count}
        </span>
      )}
      {active && (
        <motion.div 
          layoutId="active-pill"
          className="absolute left-0 w-1 h-6 bg-yellow-500 rounded-r-full"
        />
      )}
    </button>
  );
}

function MobileNavIcon({ active, icon, onClick }: { active: boolean, icon: React.ReactNode, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`p-3 rounded-2xl transition-all ${active ? 'bg-yellow-500 text-slate-900' : 'text-slate-500'}`}
    >
      {icon}
    </button>
  );
}

function StatCard({ icon, label, value, sub, night }: { icon: React.ReactNode, label: string, value: string, sub: string, night: boolean }) {
  return (
    <div className={`p-6 rounded-2xl border flex items-center gap-6 transition-all ${
      night ? 'bg-slate-900/50 border-slate-800 shadow-lg' : 'bg-white border-slate-200 shadow-sm'
    }`}>
      <div className={`p-4 rounded-2xl ${night ? 'bg-slate-800' : 'bg-slate-100'}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs uppercase tracking-widest font-bold opacity-40 mb-1">{label}</p>
        <h4 className="text-2xl font-bold">{value}</h4>
        <p className="text-[10px] font-medium opacity-60 mt-1 uppercase tracking-wider">{sub}</p>
      </div>
    </div>
  );
}

function ReportAction({ icon, label, sub, onClick, night }: { icon: React.ReactNode, label: string, sub: string, onClick: () => void, night: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`w-full p-4 rounded-2xl border text-left flex items-center gap-4 transition-all group ${
        night 
          ? 'bg-slate-800/50 border-slate-700 hover:border-yellow-500/50 hover:bg-slate-800' 
          : 'bg-slate-50 border-slate-200 hover:border-yellow-500 hover:bg-white'
      }`}
    >
      <div className={`p-3 rounded-xl transition-all ${night ? 'bg-slate-700 group-hover:bg-yellow-500/20' : 'bg-white group-hover:bg-yellow-50'}`}>
        {icon}
      </div>
      <div>
        <h4 className="font-bold text-sm">{label}</h4>
        <p className="text-[10px] opacity-60">{sub}</p>
      </div>
    </button>
  );
}
