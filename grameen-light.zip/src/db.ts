import Dexie, { Table } from 'dexie';
import { Pole, Complaint } from './types';

export class GrameenDatabase extends Dexie {
  poles!: Table<Pole>;
  complaints!: Table<Complaint>;
  offlineActions!: Table<{
    id?: number,
    type: 'REPORT' | 'UPDATE_STATUS',
    data: any,
    timestamp: number
  }>;

  constructor() {
    super('GrameenLightDB');
    this.version(1).stores({
      poles: 'id, status',
      complaints: 'id, poleId, status, timestamp',
      offlineActions: '++id, type, timestamp'
    });
  }
}

export const localDb = new GrameenDatabase();
