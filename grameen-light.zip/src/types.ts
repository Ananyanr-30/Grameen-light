
export type PoleStatus = 'Working' | 'Fused' | 'Daytime_On';

export interface Pole {
  id: string;
  status: PoleStatus;
  location: string;
  lat: number;
  lng: number;
}

export type ComplaintStatus = 'Pending' | 'Assigned' | 'Fixed';

export interface ComplaintHistoryEvent {
  status: ComplaintStatus;
  timestamp: number;
  note?: string;
  attachments?: string[];
}

export interface Complaint {
  id: string;
  poleId: string;
  issueType: PoleStatus;
  status: ComplaintStatus;
  timestamp: number;
  history: ComplaintHistoryEvent[];
  panchayatNotes?: string;
  attachments?: string[];
}

export interface VillageStats {
  totalPoles: number;
  fusedCount: number;
  daytimeOnCount: number;
  energySavedKWh: number;
  leaderboard?: { name: string; points: number; avatar: string }[];
}
