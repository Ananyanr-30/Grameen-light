package com.grameen.light;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
